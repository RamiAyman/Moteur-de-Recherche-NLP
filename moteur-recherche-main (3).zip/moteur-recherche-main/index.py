from View.tkinter import View


if __name__=="__main__":
    View() 
    


    