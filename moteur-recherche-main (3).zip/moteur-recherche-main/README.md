# moteur-recherche
search engine with NLP 

<p></p>
Développé à 100% python avec:
<p></p>

le modèle MVC
<p></p> 

une interface de vue en TKinter
<p></p>

et de la POO
<p></p>

Réalisation d'un projet python sur un moteur de recherche. Ce moteur se base sur le BOW 
(Bag Of Word)
